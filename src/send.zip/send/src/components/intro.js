import React, { useEffect, useRef, useState } from 'react'

export default function Intro() {
    const word = "Virtual Labs"
    const word2 = "Virtaul Labs"
    useEffect(() => {
    }, [])

    setTimeout(() => {
        const left = document.getElementById("left-side");
        const handleMove = e => {
            left.style.width = `calc(${e.clientX / window.innerWidth * 100}%)`;
        }
        document.onmousemove = e => handleMove(e);
        document.ontouchmove = e => handleMove(e.touches[0]);
        // word = document.getElementsByClassName('hacker')[0]
        // word2 = document.getElementsByClassName('hacker')[1]

        var interv = 'undefined'
        var canChange = false
        var globalCount = 0
        var count = 0
        var INITIAL_WORD = "Virtual Labs";
        var isGoing = false

        var interv2 = 'undefined'
        var canChange2 = false
        var globalCount2 = 0
        var count2 = 0
        var INITIAL_WORD2 = "Virtual Labs";


        function rand(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }
        function getRandomLetter() {
            var alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
            return alphabet[rand(0, alphabet.length - 1)]
        }
        function getRandomWord(word) {
            var text = "Virtual Labs"

            var finalWord = ''
            for (var i = 0; i < text.length; i++) {
                finalWord += text[i] === ' ' ? ' ' : getRandomLetter()
            }

            return finalWord
        }




        function init() {
            if (isGoing) return;
            isGoing = true
            var randomWord = getRandomWord(word)
            document.getElementsByClassName('hacker')[0].innerHTML = randomWord

            interv = setInterval(function () {
                var finalWord = ''
                for (var x = 0; x < INITIAL_WORD.length; x++) {
                    if (x <= count && canChange) {
                        finalWord += INITIAL_WORD[x]
                    } else {
                        finalWord += getRandomLetter()
                    }
                }
                document.getElementsByClassName('hacker')[0].innerHTML = finalWord
                if (canChange) {
                    count++
                }
                if (globalCount >= 20) {
                    canChange = true
                }
                if (count >= INITIAL_WORD.length) {
                    clearInterval(interv)
                    count = 0
                    canChange = false
                    globalCount = 0
                    isGoing = false
                }
                globalCount++
            }, 40)


            var randomWord2 = getRandomWord(word2)
            document.getElementsByClassName('hacker')[1].innerHTML = randomWord2

            interv2 = setInterval(function () {
                var finalWord2 = ''
                for (var x = 0; x < INITIAL_WORD2.length; x++) {
                    if (x <= count2 && canChange2) {
                        finalWord2 += INITIAL_WORD2[x]
                    } else {
                        finalWord2 += getRandomLetter()
                    }
                }
                document.getElementsByClassName('hacker')[1].innerHTML = finalWord2
                if (canChange2) {
                    count2++
                }
                if (globalCount2 >= 20) {
                    canChange2 = true
                }
                if (count2 >= INITIAL_WORD2.length) {
                    clearInterval(interv2)
                    count2 = 0
                    canChange2 = false
                    globalCount2 = 0
                }
                globalCount2++
            }, 40)

        }

        document.body.onmousemove = function (e) {
            document.documentElement.style.setProperty(
                '--x', (
                    e.clientX + window.scrollX
                )
            + 'px'
            );
            document.documentElement.style.setProperty(
                '--y', (
                    e.clientY + window.scrollY
                )
            + 'px'
            );
        }

        // hover effect
        // const trailer = document.getElementById("trailer");

        // const animateTrailer = (e, interacting) => {
        //     const x = e.clientX - trailer.offsetWidth / 2,
        //         y = e.clientY - trailer.offsetHeight / 2;

        //     const keyframes = {
        //         transform: `translate(${x}px, ${y}px) scale(${interacting ? 8 : 1})`
        //     }

        //     trailer.animate(keyframes, {
        //         duration: 800,
        //         fill: "forwards"
        //     });
        // }

        // const getTrailerClass = type => {
        //     switch (type) {
        //         case "video":
        //             return "fa-solid fa-play";
        //         default:
        //             return "fa-solid fa-arrow-up-right";
        //     }
        // }

        // window.onmousemove = e => {
        //     const interactable = e.target.closest(".interactable"),
        //         interacting = interactable !== null;

        //     const icon = document.getElementById("trailer-icon");

        //     animateTrailer(e, interacting);

        //     trailer.dataset.type = interacting ? interactable.dataset.type : "";

        //     if (interacting) {
        //         icon.className = getTrailerClass(interactable.dataset.type);
        //     }
        // }

        // body = document.querySelector('.App')
        init()
    }, 100)



    return (
        <div className='main-container'>
            {/* <div id="trailer">
                <i id="trailer-icon" className="fa-solid fa-arrow-up-right"></i>
            </div> */}

            {/* <nav>
                <div className="nav-container">
                    <ul className="nav-links">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Nice</a></li>
                        <li><a href="#">Experiments</a></li>
                        <li className="search-li"><a href="#"><i className="fa fa-search"></i></a></li>
                    </ul>
                </div>
            </nav> */}
            <div className="effect-container">
                <div id="left-side" className="side">
                    <h2 className="title">
                        <p className="hacker">Virtual Labs</p>
                    </h2>
                    <div className="desc">Virtual Labs, a mission mode MHRD project under NMEICT, provides free, laboratory learning
                        experience to students through remote experimentation. Free Workshops, are conducted and nodal centers
                        are
                        setup
                        to partner with institutes of the Virtual Labs consortium for the adoption of Virtual Labs. To keep in
                        pace
                        with
                        growing needs of students, experiments across domains are conceptualized, aligned and built using
                        cutting-edge
                        open source technologies. State of the art digital classroom is available for streaming video lectures
                        to
                        complement Virtual Lab experiments.</div>
                    {/* <!-- <div className="desc">Virtual Labs, a mission mode MHRD project under NMEICT, provides free, laboratory learning experience to students through remote experimentation. Free Workshops, are conducted and nodal centers are setup to partner with institutes of the Virtual Labs consortium for the adoption of Virtual Labs. To keep in pace with growing needs of students, experiments across domains are conceptualized, aligned and built using cutting-edge open source technologies. State of the art digital classroom is available for streaming video lectures to complement Virtual Lab experiments.</div> --> */}
                </div>
                {/* <!-- <div className="cards">Now we make scroll effect on cards using fontawesome.js</div> --> */}
                <div id="right-side" className="side">
                    <h2 className="title">
                        <p className="hacker">Virtual Labs</p>
                    </h2>
                    <div className="desc">Virtual Labs, a mission mode MHRD project under NMEICT, provides free, laboratory learning
                        experience to students through remote experimentation. Free Workshops, are conducted and nodal centers
                        are
                        setup
                        to partner with institutes of the Virtual Labs consortium for the adoption of Virtual Labs. To keep in
                        pace
                        with
                        growing needs of students, experiments across domains are conceptualized, aligned and built using
                        cutting-edge
                        open source technologies. State of the art digital classroom is available for streaming video lectures
                        to
                        complement Virtual Lab experiments.</div>
                    {/* <!-- <div className="desc">Virtual Labs, a mission mode MHRD project under NMEICT, provides free, laboratory learning experience to students through remote experimentation. Free Workshops, are conducted and nodal centers are setup to partner with institutes of the Virtual Labs consortium for the adoption of Virtual Labs. To keep in pace with growing needs of students, experiments across domains are conceptualized, aligned and built using cutting-edge open source technologies. State of the art digital classroom is available for streaming video lectures to complement Virtual Lab experiments.</div> --> */}
                </div>
            </div>
        </div>
    )
}
