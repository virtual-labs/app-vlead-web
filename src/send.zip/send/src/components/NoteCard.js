import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Chevrolet from '../images/random.jpg'
import "../css/all.css"

export default function NoteCard(note) {
  const obj = note.note
  return (
    <div className='note-card'>
      <Card sx={{ maxWidth: "500px" }}>
        <CardMedia
          component="img"
          height="240"
          image={Chevrolet}
          alt="Chevrolet"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            {obj.title}
          </Typography>
          <Typography variant="body2" color="text.secondary" fontSize={"large"}>
            Chevrolet is an iconic American car brand known for its reliable, dependable, and affordable vehicles. Founded in 1911, Chevy has become one of the most recognizable car brands in the world.
          </Typography>
        </CardContent>
        <CardActions>
          <Button size="medium">Share</Button>
          <Button size="medium">Learn More</Button>
        </CardActions>
      </Card>
    </div>
  );
}