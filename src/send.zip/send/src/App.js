import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import Intro from './components/intro'
import Notes from './pages/Notes'
import { createMuiTheme, ThemeProvider } from '@material-ui/core'
import { purple } from '@material-ui/core/colors'
import './css/all.css'
import 'font-awesome/css/font-awesome.min.css';

const theme = createMuiTheme({
  palette: {
    primary: {
      main: '#fefefe'
    },
    secondary: purple
  },
  typography: {
    fontFamily: 'Quicksand',
    fontWeightLight: 400,
    fontWeightRegular: 500,
    fontWeightMedium: 600,
    fontWeightBold: 700,
  }
})

function App() {
  return (
    // <ThemeProvider theme={theme}>

    <div>
      <Intro />
      <Notes /> // before there was a router here, maybe that was the problem, that I din't have it?
    </div>
  );
}

export default App;
